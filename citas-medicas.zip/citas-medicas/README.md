# Medical Appointments Management System

A console-based medical appointments management platform built in **Java** using
**Object-Oriented Programming (OOP)** principles, **SQLite** persistence, and an
AI assistant scoped to the medical-appointments domain via the **OpenAI API**.

## Overview

This system allows a clinic to register patients, manage doctors and their
specialties, schedule/confirm/cancel medical appointments, and consult a
domain-restricted AI assistant ("MediBot") for general orientation on
specialties and how the system works.

## Features

- Patient registration with input validation (email, phone, birth date)
- Doctor catalog organized by medical specialty
- Appointment scheduling with conflict detection (no double-booking a doctor)
- Appointment lifecycle: `PROGRAMADA -> CONFIRMADA -> COMPLETADA` or `CANCELADA`
- Email/SMS notification abstraction (`Notificable` interface, swappable channels)
- Domain-restricted AI assistant (MediBot) that only answers questions related
  to appointments, specialties, and general (non-diagnostic) health orientation
- Full SQL persistence (Create, Read, Update, Delete) using SQLite

## Architecture

The project follows a 3-layer architecture to separate concerns:

```
src/main/java/com/citasmedicas/
 |-- model/          Domain entities (Persona, Paciente, Medico, Cita, ...)
 |-- interfaces/      Notificable interface (notification contract)
 |-- notification/    Concrete notification channels (Email, SMS)
 |-- repository/       Data access layer (JDBC/SQLite, one repository per entity)
 |-- service/          Business logic layer (GestorCitas, GestorPacientes, AsistenteIA)
 |-- util/             Cross-cutting utilities (Validador)
 \-- Main.java         Console UI / entry point
```

### Key OOP concepts demonstrated

| Concept | Where |
|---|---|
| Abstraction | `Persona` is an abstract class; `getRol()` is an abstract method |
| Inheritance | `Paciente` and `Medico` extend `Persona` |
| Polymorphism | `getRol()` overridden per subclass; `Notificable` implementations (`NotificacionEmail`, `NotificacionSMS`) used interchangeably by `GestorCitas` |
| Encapsulation | All model fields are private with controlled getters/setters; `HistorialMedico` returns defensive copies of its internal list |
| Interfaces | `Notificable` |
| Composition | `HistorialMedico` owns its `EntradaHistorial` records |
| Association | `Cita` references `Paciente`, `Medico`, and `Consultorio` without owning their lifecycle |

## Database

SQLite is used for persistence (file-based, no server required). Schema and
seed data are defined in [`sql/schema.sql`](sql/schema.sql):

- `paciente`, `medico`, `especialidad`, `consultorio`, `cita`, `historial_entrada`
- Foreign keys enforce referential integrity between appointments, patients,
  doctors, and consulting rooms.

The database file (`citas_medicas.db`) is created automatically on first run.

## AI Integration (MediBot)

The system integrates OpenAI's API (`gpt-4o-mini`) through `AsistenteIA`.
The assistant is **strictly scoped to the medical-appointments domain**:

- A system prompt instructs the model to only discuss appointment scheduling,
  specialties, and general (non-diagnostic) health orientation.
- A local keyword guardrail rejects obviously off-topic questions before
  calling the API, as a defense-in-depth measure.
- The assistant never diagnoses, prescribes, or gives dosages — it redirects
  patients to consult their assigned doctor in person.

### Configuration

Set your OpenAI API key as an environment variable before running:

```bash
export OPENAI_API_KEY="your-api-key-here"
```

If the variable is not set, the rest of the system still works; only the
AI assistant menu option will report that it is not configured.

## Requirements

- Java 17 or higher (JDK)
- Maven 3.6+
- An OpenAI API key (optional, only required for the AI assistant feature)

## How to Run

```bash
# Clone the repository
git clone <your-repo-url>
cd citas-medicas

# Set your OpenAI API key (optional)
export OPENAI_API_KEY="your-api-key-here"

# Compile and run with Maven
mvn compile exec:java

# Or build a runnable JAR and execute it
mvn package
java -jar target/citas-medicas.jar
```

## Project Structure

```
citas-medicas/
 |-- pom.xml                  Maven build configuration
 |-- sql/schema.sql            Database schema and seed data
 |-- src/main/java/...         Source code (see Architecture above)
 \-- README.md                 This file
```

## Sample Data

On first run, the system seeds 3 sample doctors (Cardiology, Pediatrics, and
General Medicine) and a few consulting rooms so the demo is usable
immediately without manual setup.

## Notes on Academic Context

This project was developed as the final project for an Object-Oriented
Programming course, fulfilling requirements around OOP principles, SQL
persistence, layered architecture, version control (Git/GitHub), and scoped
AI integration via LLM APIs.
