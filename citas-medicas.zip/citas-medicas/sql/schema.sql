-- ============================================================
-- Medical Appointments System - SQLite Schema
-- ============================================================

CREATE TABLE IF NOT EXISTS especialidad (
    codigo TEXT PRIMARY KEY,
    nombre TEXT NOT NULL,
    descripcion TEXT
);

CREATE TABLE IF NOT EXISTS paciente (
    id TEXT PRIMARY KEY,
    nombre TEXT NOT NULL,
    apellido TEXT NOT NULL,
    telefono TEXT,
    email TEXT,
    fecha_nacimiento TEXT,
    tipo_sangre TEXT,
    direccion TEXT
);

CREATE TABLE IF NOT EXISTS medico (
    id TEXT PRIMARY KEY,
    nombre TEXT NOT NULL,
    apellido TEXT NOT NULL,
    telefono TEXT,
    email TEXT,
    especialidad_codigo TEXT,
    numero_licencia TEXT,
    disponible INTEGER DEFAULT 1,
    FOREIGN KEY (especialidad_codigo) REFERENCES especialidad(codigo)
);

CREATE TABLE IF NOT EXISTS consultorio (
    id TEXT PRIMARY KEY,
    numero TEXT,
    piso TEXT,
    tipo TEXT
);

CREATE TABLE IF NOT EXISTS cita (
    id TEXT PRIMARY KEY,
    paciente_id TEXT NOT NULL,
    medico_id TEXT NOT NULL,
    consultorio_id TEXT,
    fecha_hora TEXT NOT NULL,
    estado TEXT NOT NULL,
    motivo TEXT,
    notas TEXT,
    FOREIGN KEY (paciente_id) REFERENCES paciente(id),
    FOREIGN KEY (medico_id) REFERENCES medico(id),
    FOREIGN KEY (consultorio_id) REFERENCES consultorio(id)
);

CREATE TABLE IF NOT EXISTS historial_entrada (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    paciente_id TEXT NOT NULL,
    fecha TEXT NOT NULL,
    diagnostico TEXT,
    tratamiento TEXT,
    medico_id TEXT,
    FOREIGN KEY (paciente_id) REFERENCES paciente(id)
);

-- ============================================================
-- Seed data: sample specialties and a consulting room so the
-- system has something to work with right after first run.
-- ============================================================

INSERT OR IGNORE INTO especialidad (codigo, nombre, descripcion) VALUES
    ('CARD', 'Cardiologia', 'Enfermedades del corazon y sistema circulatorio'),
    ('PEDI', 'Pediatria', 'Atencion medica infantil'),
    ('DERM', 'Dermatologia', 'Enfermedades de la piel'),
    ('GENE', 'Medicina General', 'Consulta medica general');

INSERT OR IGNORE INTO consultorio (id, numero, piso, tipo) VALUES
    ('C001', '101', '1', 'Presencial'),
    ('C002', '202', '2', 'Presencial'),
    ('C003', 'V01', 'N/A', 'Virtual');
