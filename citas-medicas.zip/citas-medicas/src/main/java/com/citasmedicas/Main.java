package com.citasmedicas;

import com.citasmedicas.model.*;
import com.citasmedicas.notification.NotificacionEmail;
import com.citasmedicas.repository.*;
import com.citasmedicas.service.AsistenteIA;
import com.citasmedicas.service.GestorCitas;
import com.citasmedicas.service.GestorPacientes;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

/**
 * Entry point. Wires together repositories, services, and the console UI.
 * Demonstrates separation of the UI layer from business logic: this class
 * only handles input/output and delegates all real work to the service layer.
 */
public class Main {

    private static final Scanner scanner = new Scanner(System.in);
    private static GestorCitas gestorCitas;
    private static GestorPacientes gestorPacientes;
    private static RepositorioMedico repositorioMedico;
    private static RepositorioEspecialidad repositorioEspecialidad;
    private static AsistenteIA asistenteIA;

    public static void main(String[] args) {
        ConexionBD.inicializarBaseDatos();

        RepositorioCitas repositorioCitas = new RepositorioCitas();
        RepositorioPaciente repositorioPaciente = new RepositorioPaciente();
        repositorioMedico = new RepositorioMedico();
        repositorioEspecialidad = new RepositorioEspecialidad();

        gestorCitas = new GestorCitas(repositorioCitas, repositorioPaciente, repositorioMedico,
                new NotificacionEmail());
        gestorPacientes = new GestorPacientes(repositorioPaciente);

        String apiKey = System.getenv("OPENAI_API_KEY");
        asistenteIA = new AsistenteIA(apiKey);

        sembrarMedicosDePrueba();

        System.out.println("=================================================");
        System.out.println(" SISTEMA DE GESTION DE CITAS MEDICAS");
        System.out.println("=================================================");

        boolean salir = false;
        while (!salir) {
            mostrarMenu();
            String opcion = scanner.nextLine().trim();
            switch (opcion) {
                case "1" -> registrarPaciente();
                case "2" -> agendarCita();
                case "3" -> listarCitasPorPaciente();
                case "4" -> cancelarCita();
                case "5" -> confirmarCita();
                case "6" -> listarMedicos();
                case "7" -> preguntarAsistenteIA();
                case "0" -> salir = true;
                default -> System.out.println("Opcion invalida, intente de nuevo.");
            }
        }

        ConexionBD.cerrarConexion();
        System.out.println("Sistema cerrado. Hasta luego.");
    }

    private static void mostrarMenu() {
        System.out.println("\n--- MENU PRINCIPAL ---");
        System.out.println("1. Registrar paciente");
        System.out.println("2. Agendar cita");
        System.out.println("3. Ver citas de un paciente");
        System.out.println("4. Cancelar cita");
        System.out.println("5. Confirmar cita");
        System.out.println("6. Listar medicos disponibles");
        System.out.println("7. Preguntar al asistente de IA (MediBot)");
        System.out.println("0. Salir");
        System.out.print("Seleccione una opcion: ");
    }

    private static void registrarPaciente() {
        System.out.println("\n--- Registro de Paciente ---");
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine().trim();
        System.out.print("Apellido: ");
        String apellido = scanner.nextLine().trim();
        System.out.print("Telefono (ej. +50688887777): ");
        String telefono = scanner.nextLine().trim();
        System.out.print("Email: ");
        String email = scanner.nextLine().trim();
        System.out.print("Fecha de nacimiento (YYYY-MM-DD): ");
        String fechaStr = scanner.nextLine().trim();
        System.out.print("Tipo de sangre (opcional): ");
        String tipoSangre = scanner.nextLine().trim();
        System.out.print("Direccion (opcional): ");
        String direccion = scanner.nextLine().trim();

        LocalDate fechaNacimiento;
        try {
            fechaNacimiento = LocalDate.parse(fechaStr);
        } catch (DateTimeParseException e) {
            System.out.println("Formato de fecha invalido. Use YYYY-MM-DD.");
            return;
        }

        GestorCitas.ResultadoOperacion resultado = gestorPacientes.registrarPaciente(
                nombre, apellido, telefono, email, fechaNacimiento, tipoSangre, direccion);
        System.out.println(resultado.getMensaje());
    }

    private static void agendarCita() {
        System.out.println("\n--- Agendar Cita ---");
        System.out.print("ID del paciente (ej. PAC-XXXXXXXX): ");
        String pacienteId = scanner.nextLine().trim();

        listarMedicos();
        System.out.print("ID del medico (ej. MED-XXXXXXXX): ");
        String medicoId = scanner.nextLine().trim();

        System.out.print("Fecha y hora (YYYY-MM-DDTHH:MM, ej. 2026-06-20T10:30): ");
        String fechaStr = scanner.nextLine().trim();

        System.out.print("Motivo de la cita: ");
        String motivo = scanner.nextLine().trim();

        LocalDateTime fechaHora;
        try {
            fechaHora = LocalDateTime.parse(fechaStr);
        } catch (DateTimeParseException e) {
            System.out.println("Formato de fecha/hora invalido.");
            return;
        }

        List<Consultorio> consultorios = new RepositorioConsultorio().listarTodos();
        Consultorio consultorio = consultorios.isEmpty() ? null : consultorios.get(0);

        GestorCitas.ResultadoOperacion resultado = gestorCitas.agendarCita(
                pacienteId, medicoId, consultorio, fechaHora, motivo);
        System.out.println(resultado.getMensaje());
    }

    private static void listarCitasPorPaciente() {
        System.out.print("\nID del paciente: ");
        String pacienteId = scanner.nextLine().trim();
        List<Cita> citas = gestorCitas.listarCitasPorPaciente(pacienteId);
        if (citas.isEmpty()) {
            System.out.println("No se encontraron citas para este paciente.");
            return;
        }
        citas.forEach(System.out::println);
    }

    private static void cancelarCita() {
        System.out.print("\nID de la cita a cancelar: ");
        String citaId = scanner.nextLine().trim();
        GestorCitas.ResultadoOperacion resultado = gestorCitas.cancelarCita(citaId);
        System.out.println(resultado.getMensaje());
    }

    private static void confirmarCita() {
        System.out.print("\nID de la cita a confirmar: ");
        String citaId = scanner.nextLine().trim();
        GestorCitas.ResultadoOperacion resultado = gestorCitas.confirmarCita(citaId);
        System.out.println(resultado.getMensaje());
    }

    private static void listarMedicos() {
        System.out.println("\n--- Medicos disponibles ---");
        List<Medico> medicos = repositorioMedico.listarTodos();
        if (medicos.isEmpty()) {
            System.out.println("No hay medicos registrados.");
            return;
        }
        medicos.forEach(System.out::println);
    }

    private static void preguntarAsistenteIA() {
        System.out.println("\n--- MediBot (Asistente de IA) ---");
        System.out.println("Puede preguntar sobre especialidades, sintomas generales u orientacion del sistema.");
        System.out.print("Su pregunta: ");
        String pregunta = scanner.nextLine().trim();
        String respuesta = asistenteIA.preguntar(pregunta);
        System.out.println("\nMediBot: " + respuesta);
    }

    /**
     * Seeds a couple of sample doctors on first run so the demo is usable
     * immediately without manual setup. Skips silently if already present.
     */
    private static void sembrarMedicosDePrueba() {
        if (!repositorioMedico.listarTodos().isEmpty()) {
            return;
        }
        Optional<Especialidad> cardiologia = repositorioEspecialidad.buscarPorCodigo("CARD");
        Optional<Especialidad> pediatria = repositorioEspecialidad.buscarPorCodigo("PEDI");
        Optional<Especialidad> general = repositorioEspecialidad.buscarPorCodigo("GENE");

        cardiologia.ifPresent(esp -> repositorioMedico.guardar(
                new Medico("MED-00000001", "Laura", "Jimenez", "+50688881111",
                        "laura.jimenez@clinica.com", esp, "LIC-1001")));
        pediatria.ifPresent(esp -> repositorioMedico.guardar(
                new Medico("MED-00000002", "Carlos", "Vargas", "+50688882222",
                        "carlos.vargas@clinica.com", esp, "LIC-1002")));
        general.ifPresent(esp -> repositorioMedico.guardar(
                new Medico("MED-00000003", "Ana", "Mora", "+50688883333",
                        "ana.mora@clinica.com", esp, "LIC-1003")));
    }
}
