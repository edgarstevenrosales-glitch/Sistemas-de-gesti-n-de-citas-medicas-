package com.citasmedicas.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.regex.Pattern;

/**
 * Utility class with static validation methods used across the service layer.
 * Keeping validation logic centralized avoids duplicating checks (DRY principle).
 */
public final class Validador {

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[\\w.+-]+@[\\w-]+\\.[a-zA-Z]{2,}$");

    private Validador() {
        // utility class, no instances
    }

    public static boolean esEmailValido(String email) {
        return email != null && EMAIL_PATTERN.matcher(email).matches();
    }

    public static boolean esTelefonoValido(String telefono) {
        return telefono != null && telefono.replaceAll("[\\s\\-()]", "").matches("\\+?\\d{7,15}");
    }

    public static boolean esTextoNoVacio(String texto) {
        return texto != null && !texto.trim().isEmpty();
    }

    public static boolean esFechaFutura(LocalDateTime fechaHora) {
        return fechaHora != null && fechaHora.isAfter(LocalDateTime.now());
    }

    public static boolean esFechaNacimientoValida(LocalDate fecha) {
        return fecha != null && fecha.isBefore(LocalDate.now()) && fecha.isAfter(LocalDate.now().minusYears(120));
    }
}
