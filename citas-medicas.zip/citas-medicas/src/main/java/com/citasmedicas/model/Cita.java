package com.citasmedicas.model;

import java.time.LocalDateTime;

/**
 * Represents a medical appointment.
 * Demonstrates ASSOCIATION: a Cita references a Paciente, a Medico, and a Consultorio
 * without owning their lifecycle (they exist independently of the appointment).
 */
public class Cita {

    private String id;
    private Paciente paciente;
    private Medico medico;
    private Consultorio consultorio;
    private LocalDateTime fechaHora;
    private EstadoCita estado;
    private String motivo;
    private String notas;

    public Cita(String id, Paciente paciente, Medico medico, Consultorio consultorio,
                LocalDateTime fechaHora, String motivo) {
        this.id = id;
        this.paciente = paciente;
        this.medico = medico;
        this.consultorio = consultorio;
        this.fechaHora = fechaHora;
        this.motivo = motivo;
        this.estado = EstadoCita.PROGRAMADA;
        this.notas = "";
    }

    public String getId() {
        return id;
    }

    public Paciente getPaciente() {
        return paciente;
    }

    public Medico getMedico() {
        return medico;
    }

    public Consultorio getConsultorio() {
        return consultorio;
    }

    public LocalDateTime getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(LocalDateTime fechaHora) {
        this.fechaHora = fechaHora;
    }

    public EstadoCita getEstado() {
        return estado;
    }

    public void setEstado(EstadoCita estado) {
        this.estado = estado;
    }

    public String getMotivo() {
        return motivo;
    }

    public String getNotas() {
        return notas;
    }

    public void setNotas(String notas) {
        this.notas = notas;
    }

    public void confirmar() {
        this.estado = EstadoCita.CONFIRMADA;
    }

    public void cancelar() {
        this.estado = EstadoCita.CANCELADA;
    }

    public void completar(String notasConsulta) {
        this.estado = EstadoCita.COMPLETADA;
        this.notas = notasConsulta;
    }

    @Override
    public String toString() {
        return String.format("Cita[%s] %s - Paciente: %s | Medico: %s | %s | Estado: %s",
                id, fechaHora, paciente.getNombreCompleto(), medico.getNombreCompleto(),
                consultorio, estado);
    }
}
