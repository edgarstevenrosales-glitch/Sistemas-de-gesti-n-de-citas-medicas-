package com.citasmedicas.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents the medical history of a patient: a log of entries (diagnoses,
 * treatments, allergies) accumulated over time.
 * Demonstrates COMPOSITION: an EntradaHistorial cannot exist meaningfully
 * without its parent HistorialMedico (it's a nested static class), and the
 * HistorialMedico's internal list is fully encapsulated.
 */
public class HistorialMedico {

    private String pacienteId;
    private List<EntradaHistorial> entradas;

    public HistorialMedico(String pacienteId) {
        this.pacienteId = pacienteId;
        this.entradas = new ArrayList<>();
    }

    public String getPacienteId() {
        return pacienteId;
    }

    public void agregarEntrada(String diagnostico, String tratamiento, String medicoId) {
        entradas.add(new EntradaHistorial(LocalDateTime.now(), diagnostico, tratamiento, medicoId));
    }

    public List<EntradaHistorial> getEntradas() {
        return new ArrayList<>(entradas); // defensive copy preserves encapsulation
    }

    /**
     * Nested class representing a single record within the medical history.
     * Demonstrates COMPOSITION: instances only make sense inside a HistorialMedico.
     */
    public static class EntradaHistorial {
        private final LocalDateTime fecha;
        private final String diagnostico;
        private final String tratamiento;
        private final String medicoId;

        public EntradaHistorial(LocalDateTime fecha, String diagnostico, String tratamiento, String medicoId) {
            this.fecha = fecha;
            this.diagnostico = diagnostico;
            this.tratamiento = tratamiento;
            this.medicoId = medicoId;
        }

        public LocalDateTime getFecha() {
            return fecha;
        }

        public String getDiagnostico() {
            return diagnostico;
        }

        public String getTratamiento() {
            return tratamiento;
        }

        public String getMedicoId() {
            return medicoId;
        }

        @Override
        public String toString() {
            return String.format("[%s] Diagnostico: %s | Tratamiento: %s (Medico: %s)",
                    fecha, diagnostico, tratamiento, medicoId);
        }
    }
}
