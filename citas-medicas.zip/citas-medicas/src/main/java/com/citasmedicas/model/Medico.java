package com.citasmedicas.model;

/**
 * Represents a doctor in the system.
 * Demonstrates INHERITANCE: extends Persona and reuses all of its base fields/behavior.
 */
public class Medico extends Persona {

    private Especialidad especialidad;
    private String numeroLicencia;
    private boolean disponible;

    public Medico(String id, String nombre, String apellido, String telefono, String email,
                  Especialidad especialidad, String numeroLicencia) {
        super(id, nombre, apellido, telefono, email);
        this.especialidad = especialidad;
        this.numeroLicencia = numeroLicencia;
        this.disponible = true;
    }

    public Especialidad getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(Especialidad especialidad) {
        this.especialidad = especialidad;
    }

    public String getNumeroLicencia() {
        return numeroLicencia;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    /**
     * Overrides the abstract method from Persona.
     * Demonstrates POLYMORPHISM: a Medico and a Paciente respond differently to getRol().
     */
    @Override
    public String getRol() {
        return "Medico";
    }

    @Override
    public String toString() {
        return super.toString() + " - Especialidad: " + especialidad.getNombre();
    }
}
