package com.citasmedicas.model;

/**
 * Represents a medical specialty (e.g., Cardiology, Pediatrics).
 * Used by Doctor and referenced when scheduling an Appointment.
 */
public class Especialidad {

    private String codigo;
    private String nombre;
    private String descripcion;

    public Especialidad(String codigo, String nombre, String descripcion) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    @Override
    public String toString() {
        return nombre;
    }
}
