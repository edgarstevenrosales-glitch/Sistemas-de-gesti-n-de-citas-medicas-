package com.citasmedicas.model;

/**
 * Represents the lifecycle states of an Appointment.
 */
public enum EstadoCita {
    PROGRAMADA,
    CONFIRMADA,
    CANCELADA,
    COMPLETADA,
    NO_ASISTIO
}
