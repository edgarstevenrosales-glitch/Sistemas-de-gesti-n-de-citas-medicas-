package com.citasmedicas.model;

import java.time.LocalDate;
import java.time.Period;

/**
 * Represents a patient in the system.
 * Demonstrates INHERITANCE: extends Persona.
 */
public class Paciente extends Persona {

    private LocalDate fechaNacimiento;
    private String tipoSangre;
    private String direccion;

    public Paciente(String id, String nombre, String apellido, String telefono, String email,
                     LocalDate fechaNacimiento, String tipoSangre, String direccion) {
        super(id, nombre, apellido, telefono, email);
        this.fechaNacimiento = fechaNacimiento;
        this.tipoSangre = tipoSangre;
        this.direccion = direccion;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getTipoSangre() {
        return tipoSangre;
    }

    public void setTipoSangre(String tipoSangre) {
        this.tipoSangre = tipoSangre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getEdad() {
        if (fechaNacimiento == null) {
            return 0;
        }
        return Period.between(fechaNacimiento, LocalDate.now()).getYears();
    }

    @Override
    public String getRol() {
        return "Paciente";
    }

    @Override
    public String toString() {
        return super.toString() + " - Edad: " + getEdad();
    }
}
