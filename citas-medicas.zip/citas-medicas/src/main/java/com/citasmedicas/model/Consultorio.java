package com.citasmedicas.model;

/**
 * Represents a physical or virtual consulting room where appointments take place.
 */
public class Consultorio {

    private String id;
    private String numero;
    private String piso;
    private String tipo; // e.g., "Presencial", "Virtual"

    public Consultorio(String id, String numero, String piso, String tipo) {
        this.id = id;
        this.numero = numero;
        this.piso = piso;
        this.tipo = tipo;
    }

    public String getId() {
        return id;
    }

    public String getNumero() {
        return numero;
    }

    public String getPiso() {
        return piso;
    }

    public String getTipo() {
        return tipo;
    }

    @Override
    public String toString() {
        return "Consultorio " + numero + " (Piso " + piso + ", " + tipo + ")";
    }
}
