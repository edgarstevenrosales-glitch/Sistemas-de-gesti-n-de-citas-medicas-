package com.citasmedicas.model;

/**
 * Abstract base class representing a person in the medical system.
 * Demonstrates ABSTRACTION: it cannot be instantiated directly, only
 * through its subclasses (Patient, Doctor).
 * Demonstrates ENCAPSULATION: all fields are private with controlled access.
 */
public abstract class Persona {

    private String id;
    private String nombre;
    private String apellido;
    private String telefono;
    private String email;

    protected Persona(String id, String nombre, String apellido, String telefono, String email) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.email = email;
    }

    public String getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNombreCompleto() {
        return nombre + " " + apellido;
    }

    /**
     * Abstract method forcing every subclass to define its own role.
     * Demonstrates POLYMORPHISM when called on a Persona reference.
     */
    public abstract String getRol();

    @Override
    public String toString() {
        return String.format("%s [%s] - %s (%s)", getRol(), id, getNombreCompleto(), email);
    }
}
