package com.citasmedicas.repository;

import com.citasmedicas.model.Especialidad;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Data access object for Especialidad.
 */
public class RepositorioEspecialidad {

    public List<Especialidad> listarTodas() {
        List<Especialidad> especialidades = new ArrayList<>();
        String sql = "SELECT * FROM especialidad ORDER BY nombre";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                especialidades.add(new Especialidad(
                        rs.getString("codigo"),
                        rs.getString("nombre"),
                        rs.getString("descripcion")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error al listar especialidades: " + e.getMessage());
        }
        return especialidades;
    }

    public Optional<Especialidad> buscarPorCodigo(String codigo) {
        String sql = "SELECT * FROM especialidad WHERE codigo = ?";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql)) {
            ps.setString(1, codigo);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(new Especialidad(
                            rs.getString("codigo"),
                            rs.getString("nombre"),
                            rs.getString("descripcion")
                    ));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar especialidad: " + e.getMessage());
        }
        return Optional.empty();
    }
}
