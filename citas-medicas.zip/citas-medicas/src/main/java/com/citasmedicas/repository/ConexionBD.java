package com.citasmedicas.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * Manages the single SQLite connection used across the application.
 * Demonstrates separation of the DATA ACCESS layer from business logic.
 */
public class ConexionBD {

    private static final String DB_URL = "jdbc:sqlite:citas_medicas.db";
    private static Connection connection;

    private ConexionBD() {
        // utility class, no instances
    }

    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            connection = DriverManager.getConnection(DB_URL);
        }
        return connection;
    }

    /**
     * Initializes the database schema by executing sql/schema.sql if the
     * core tables do not exist yet.
     */
    public static void inicializarBaseDatos() {
        try {
            Connection conn = getConnection();
            String schemaPath = "sql/schema.sql";
            String script;

            if (Files.exists(Paths.get(schemaPath))) {
                script = new String(Files.readAllBytes(Paths.get(schemaPath)));
            } else {
                System.out.println("Advertencia: no se encontro sql/schema.sql, usando esquema embebido.");
                script = EsquemaEmbebido.SCRIPT;
            }

            try (Statement stmt = conn.createStatement()) {
                for (String sentenciaSql : script.split(";")) {
                    String trimmed = sentenciaSql.trim();
                    if (!trimmed.isEmpty()) {
                        stmt.execute(trimmed);
                    }
                }
            }
            System.out.println("Base de datos inicializada correctamente: citas_medicas.db");
        } catch (Exception e) {
            System.err.println("Error al inicializar la base de datos: " + e.getMessage());
        }
    }

    public static void cerrarConexion() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            System.err.println("Error al cerrar la conexion: " + e.getMessage());
        }
    }

    /**
     * Fallback schema embedded in code in case sql/schema.sql is not found
     * relative to the working directory (e.g., run from a different folder).
     */
    private static class EsquemaEmbebido {
        static final String SCRIPT =
            "CREATE TABLE IF NOT EXISTS especialidad (" +
            " codigo TEXT PRIMARY KEY, nombre TEXT NOT NULL, descripcion TEXT);" +
            "CREATE TABLE IF NOT EXISTS paciente (" +
            " id TEXT PRIMARY KEY, nombre TEXT NOT NULL, apellido TEXT NOT NULL," +
            " telefono TEXT, email TEXT, fecha_nacimiento TEXT, tipo_sangre TEXT, direccion TEXT);" +
            "CREATE TABLE IF NOT EXISTS medico (" +
            " id TEXT PRIMARY KEY, nombre TEXT NOT NULL, apellido TEXT NOT NULL," +
            " telefono TEXT, email TEXT, especialidad_codigo TEXT, numero_licencia TEXT," +
            " disponible INTEGER DEFAULT 1," +
            " FOREIGN KEY (especialidad_codigo) REFERENCES especialidad(codigo));" +
            "CREATE TABLE IF NOT EXISTS consultorio (" +
            " id TEXT PRIMARY KEY, numero TEXT, piso TEXT, tipo TEXT);" +
            "CREATE TABLE IF NOT EXISTS cita (" +
            " id TEXT PRIMARY KEY, paciente_id TEXT NOT NULL, medico_id TEXT NOT NULL," +
            " consultorio_id TEXT, fecha_hora TEXT NOT NULL, estado TEXT NOT NULL," +
            " motivo TEXT, notas TEXT," +
            " FOREIGN KEY (paciente_id) REFERENCES paciente(id)," +
            " FOREIGN KEY (medico_id) REFERENCES medico(id)," +
            " FOREIGN KEY (consultorio_id) REFERENCES consultorio(id));" +
            "CREATE TABLE IF NOT EXISTS historial_entrada (" +
            " id INTEGER PRIMARY KEY AUTOINCREMENT, paciente_id TEXT NOT NULL," +
            " fecha TEXT NOT NULL, diagnostico TEXT, tratamiento TEXT, medico_id TEXT," +
            " FOREIGN KEY (paciente_id) REFERENCES paciente(id));";
    }
}
