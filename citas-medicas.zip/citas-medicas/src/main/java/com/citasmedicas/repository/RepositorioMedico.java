package com.citasmedicas.repository;

import com.citasmedicas.model.Especialidad;
import com.citasmedicas.model.Medico;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Data access object for Medico. Implements full CRUD.
 */
public class RepositorioMedico {

    public boolean guardar(Medico medico) {
        String sql = "INSERT INTO medico (id, nombre, apellido, telefono, email, " +
                "especialidad_codigo, numero_licencia, disponible) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql)) {
            ps.setString(1, medico.getId());
            ps.setString(2, medico.getNombre());
            ps.setString(3, medico.getApellido());
            ps.setString(4, medico.getTelefono());
            ps.setString(5, medico.getEmail());
            ps.setString(6, medico.getEspecialidad().getCodigo());
            ps.setString(7, medico.getNumeroLicencia());
            ps.setInt(8, medico.isDisponible() ? 1 : 0);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al guardar medico: " + e.getMessage());
            return false;
        }
    }

    public Optional<Medico> buscarPorId(String id) {
        String sql = "SELECT m.*, e.nombre as esp_nombre, e.descripcion as esp_desc " +
                "FROM medico m JOIN especialidad e ON m.especialidad_codigo = e.codigo " +
                "WHERE m.id = ?";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql)) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapearMedico(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar medico: " + e.getMessage());
        }
        return Optional.empty();
    }

    public List<Medico> listarTodos() {
        List<Medico> medicos = new ArrayList<>();
        String sql = "SELECT m.*, e.nombre as esp_nombre, e.descripcion as esp_desc " +
                "FROM medico m JOIN especialidad e ON m.especialidad_codigo = e.codigo " +
                "ORDER BY m.apellido";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                medicos.add(mapearMedico(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al listar medicos: " + e.getMessage());
        }
        return medicos;
    }

    public List<Medico> listarPorEspecialidad(String codigoEspecialidad) {
        List<Medico> medicos = new ArrayList<>();
        String sql = "SELECT m.*, e.nombre as esp_nombre, e.descripcion as esp_desc " +
                "FROM medico m JOIN especialidad e ON m.especialidad_codigo = e.codigo " +
                "WHERE m.especialidad_codigo = ? AND m.disponible = 1";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql)) {
            ps.setString(1, codigoEspecialidad);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    medicos.add(mapearMedico(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al listar medicos por especialidad: " + e.getMessage());
        }
        return medicos;
    }

    public boolean actualizar(Medico medico) {
        String sql = "UPDATE medico SET nombre=?, apellido=?, telefono=?, email=?, " +
                "especialidad_codigo=?, numero_licencia=?, disponible=? WHERE id=?";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql)) {
            ps.setString(1, medico.getNombre());
            ps.setString(2, medico.getApellido());
            ps.setString(3, medico.getTelefono());
            ps.setString(4, medico.getEmail());
            ps.setString(5, medico.getEspecialidad().getCodigo());
            ps.setString(6, medico.getNumeroLicencia());
            ps.setInt(7, medico.isDisponible() ? 1 : 0);
            ps.setString(8, medico.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar medico: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(String id) {
        String sql = "DELETE FROM medico WHERE id = ?";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql)) {
            ps.setString(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar medico: " + e.getMessage());
            return false;
        }
    }

    private Medico mapearMedico(ResultSet rs) throws SQLException {
        Especialidad especialidad = new Especialidad(
                rs.getString("especialidad_codigo"),
                rs.getString("esp_nombre"),
                rs.getString("esp_desc")
        );
        Medico medico = new Medico(
                rs.getString("id"),
                rs.getString("nombre"),
                rs.getString("apellido"),
                rs.getString("telefono"),
                rs.getString("email"),
                especialidad,
                rs.getString("numero_licencia")
        );
        medico.setDisponible(rs.getInt("disponible") == 1);
        return medico;
    }
}
