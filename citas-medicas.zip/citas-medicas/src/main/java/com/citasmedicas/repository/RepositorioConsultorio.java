package com.citasmedicas.repository;

import com.citasmedicas.model.Consultorio;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Data access object for Consultorio.
 */
public class RepositorioConsultorio {

    public List<Consultorio> listarTodos() {
        List<Consultorio> consultorios = new ArrayList<>();
        String sql = "SELECT * FROM consultorio ORDER BY numero";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                consultorios.add(mapear(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al listar consultorios: " + e.getMessage());
        }
        return consultorios;
    }

    public Optional<Consultorio> buscarPorId(String id) {
        String sql = "SELECT * FROM consultorio WHERE id = ?";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql)) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapear(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar consultorio: " + e.getMessage());
        }
        return Optional.empty();
    }

    private Consultorio mapear(ResultSet rs) throws SQLException {
        return new Consultorio(
                rs.getString("id"),
                rs.getString("numero"),
                rs.getString("piso"),
                rs.getString("tipo")
        );
    }
}
