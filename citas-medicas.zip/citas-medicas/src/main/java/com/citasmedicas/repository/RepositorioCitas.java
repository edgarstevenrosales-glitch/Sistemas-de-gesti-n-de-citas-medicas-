package com.citasmedicas.repository;

import com.citasmedicas.model.*;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Data access object for Cita (Appointment).
 * Implements full CRUD and reconstructs full object graphs (Paciente, Medico,
 * Consultorio) via joins, delegating to the other repositories to avoid
 * duplicating mapping logic.
 */
public class RepositorioCitas {

    private final RepositorioPaciente repositorioPaciente = new RepositorioPaciente();
    private final RepositorioMedico repositorioMedico = new RepositorioMedico();
    private final RepositorioConsultorio repositorioConsultorio = new RepositorioConsultorio();

    public boolean guardar(Cita cita) {
        String sql = "INSERT INTO cita (id, paciente_id, medico_id, consultorio_id, " +
                "fecha_hora, estado, motivo, notas) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql)) {
            ps.setString(1, cita.getId());
            ps.setString(2, cita.getPaciente().getId());
            ps.setString(3, cita.getMedico().getId());
            ps.setString(4, cita.getConsultorio() != null ? cita.getConsultorio().getId() : null);
            ps.setString(5, cita.getFechaHora().toString());
            ps.setString(6, cita.getEstado().name());
            ps.setString(7, cita.getMotivo());
            ps.setString(8, cita.getNotas());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al guardar cita: " + e.getMessage());
            return false;
        }
    }

    public Optional<Cita> buscarPorId(String id) {
        String sql = "SELECT * FROM cita WHERE id = ?";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql)) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapearCita(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar cita: " + e.getMessage());
        }
        return Optional.empty();
    }

    public List<Cita> listarTodas() {
        List<Cita> citas = new ArrayList<>();
        String sql = "SELECT * FROM cita ORDER BY fecha_hora";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                mapearCita(rs).ifPresent(citas::add);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar citas: " + e.getMessage());
        }
        return citas;
    }

    public List<Cita> listarPorPaciente(String pacienteId) {
        List<Cita> citas = new ArrayList<>();
        String sql = "SELECT * FROM cita WHERE paciente_id = ? ORDER BY fecha_hora";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql)) {
            ps.setString(1, pacienteId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    mapearCita(rs).ifPresent(citas::add);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al listar citas por paciente: " + e.getMessage());
        }
        return citas;
    }

    public List<Cita> listarPorMedico(String medicoId) {
        List<Cita> citas = new ArrayList<>();
        String sql = "SELECT * FROM cita WHERE medico_id = ? ORDER BY fecha_hora";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql)) {
            ps.setString(1, medicoId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    mapearCita(rs).ifPresent(citas::add);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al listar citas por medico: " + e.getMessage());
        }
        return citas;
    }

    public boolean actualizarEstado(String citaId, EstadoCita nuevoEstado) {
        String sql = "UPDATE cita SET estado = ? WHERE id = ?";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql)) {
            ps.setString(1, nuevoEstado.name());
            ps.setString(2, citaId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar estado de cita: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizar(Cita cita) {
        String sql = "UPDATE cita SET fecha_hora=?, estado=?, motivo=?, notas=? WHERE id=?";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql)) {
            ps.setString(1, cita.getFechaHora().toString());
            ps.setString(2, cita.getEstado().name());
            ps.setString(3, cita.getMotivo());
            ps.setString(4, cita.getNotas());
            ps.setString(5, cita.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar cita: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(String id) {
        String sql = "DELETE FROM cita WHERE id = ?";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql)) {
            ps.setString(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar cita: " + e.getMessage());
            return false;
        }
    }

    /**
     * Checks whether a doctor already has an appointment at the exact date/time,
     * used by the service layer to prevent double-booking.
     */
    public boolean existeConflictoHorario(String medicoId, LocalDateTime fechaHora) {
        String sql = "SELECT COUNT(*) FROM cita WHERE medico_id = ? AND fecha_hora = ? AND estado != 'CANCELADA'";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql)) {
            ps.setString(1, medicoId);
            ps.setString(2, fechaHora.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al verificar conflicto de horario: " + e.getMessage());
        }
        return false;
    }

    private Optional<Cita> mapearCita(ResultSet rs) throws SQLException {
        String pacienteId = rs.getString("paciente_id");
        String medicoId = rs.getString("medico_id");
        String consultorioId = rs.getString("consultorio_id");

        Optional<Paciente> paciente = repositorioPaciente.buscarPorId(pacienteId);
        Optional<Medico> medico = repositorioMedico.buscarPorId(medicoId);
        Consultorio consultorio = consultorioId != null
                ? repositorioConsultorio.buscarPorId(consultorioId).orElse(null)
                : null;

        if (paciente.isEmpty() || medico.isEmpty()) {
            return Optional.empty(); // data integrity issue: referenced entity missing
        }

        Cita cita = new Cita(
                rs.getString("id"),
                paciente.get(),
                medico.get(),
                consultorio,
                LocalDateTime.parse(rs.getString("fecha_hora")),
                rs.getString("motivo")
        );
        cita.setEstado(EstadoCita.valueOf(rs.getString("estado")));
        cita.setNotas(rs.getString("notas"));
        return Optional.of(cita);
    }
}
