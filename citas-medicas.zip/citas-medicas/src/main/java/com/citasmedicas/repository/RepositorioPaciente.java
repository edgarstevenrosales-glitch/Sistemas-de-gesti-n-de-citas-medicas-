package com.citasmedicas.repository;

import com.citasmedicas.model.Paciente;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Data access object for Paciente. Encapsulates all SQL statements
 * related to patients, implementing full CRUD (Create, Read, Update, Delete).
 */
public class RepositorioPaciente {

    public boolean guardar(Paciente paciente) {
        String sql = "INSERT INTO paciente (id, nombre, apellido, telefono, email, " +
                "fecha_nacimiento, tipo_sangre, direccion) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql)) {
            ps.setString(1, paciente.getId());
            ps.setString(2, paciente.getNombre());
            ps.setString(3, paciente.getApellido());
            ps.setString(4, paciente.getTelefono());
            ps.setString(5, paciente.getEmail());
            ps.setString(6, paciente.getFechaNacimiento() != null ? paciente.getFechaNacimiento().toString() : null);
            ps.setString(7, paciente.getTipoSangre());
            ps.setString(8, paciente.getDireccion());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al guardar paciente: " + e.getMessage());
            return false;
        }
    }

    public Optional<Paciente> buscarPorId(String id) {
        String sql = "SELECT * FROM paciente WHERE id = ?";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql)) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapearPaciente(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar paciente: " + e.getMessage());
        }
        return Optional.empty();
    }

    public List<Paciente> listarTodos() {
        List<Paciente> pacientes = new ArrayList<>();
        String sql = "SELECT * FROM paciente ORDER BY apellido, nombre";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                pacientes.add(mapearPaciente(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al listar pacientes: " + e.getMessage());
        }
        return pacientes;
    }

    public boolean actualizar(Paciente paciente) {
        String sql = "UPDATE paciente SET nombre=?, apellido=?, telefono=?, email=?, " +
                "fecha_nacimiento=?, tipo_sangre=?, direccion=? WHERE id=?";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql)) {
            ps.setString(1, paciente.getNombre());
            ps.setString(2, paciente.getApellido());
            ps.setString(3, paciente.getTelefono());
            ps.setString(4, paciente.getEmail());
            ps.setString(5, paciente.getFechaNacimiento() != null ? paciente.getFechaNacimiento().toString() : null);
            ps.setString(6, paciente.getTipoSangre());
            ps.setString(7, paciente.getDireccion());
            ps.setString(8, paciente.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar paciente: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(String id) {
        String sql = "DELETE FROM paciente WHERE id = ?";
        try (PreparedStatement ps = ConexionBD.getConnection().prepareStatement(sql)) {
            ps.setString(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar paciente: " + e.getMessage());
            return false;
        }
    }

    private Paciente mapearPaciente(ResultSet rs) throws SQLException {
        String fechaStr = rs.getString("fecha_nacimiento");
        LocalDate fechaNacimiento = (fechaStr != null && !fechaStr.isEmpty())
                ? LocalDate.parse(fechaStr) : null;
        return new Paciente(
                rs.getString("id"),
                rs.getString("nombre"),
                rs.getString("apellido"),
                rs.getString("telefono"),
                rs.getString("email"),
                fechaNacimiento,
                rs.getString("tipo_sangre"),
                rs.getString("direccion")
        );
    }
}
