package com.citasmedicas.service;

import com.citasmedicas.model.Paciente;
import com.citasmedicas.repository.RepositorioPaciente;
import com.citasmedicas.util.Validador;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

/**
 * Business logic for registering and managing patients.
 */
public class GestorPacientes {

    private final RepositorioPaciente repositorioPaciente;

    public GestorPacientes(RepositorioPaciente repositorioPaciente) {
        this.repositorioPaciente = repositorioPaciente;
    }

    public GestorCitas.ResultadoOperacion registrarPaciente(String nombre, String apellido, String telefono,
                                       String email, LocalDate fechaNacimiento, String tipoSangre, String direccion) {
        if (!Validador.esTextoNoVacio(nombre) || !Validador.esTextoNoVacio(apellido)) {
            return GestorCitas.ResultadoOperacion.error("Nombre y apellido son obligatorios.");
        }
        if (!Validador.esEmailValido(email)) {
            return GestorCitas.ResultadoOperacion.error("El email no tiene un formato valido.");
        }
        if (!Validador.esTelefonoValido(telefono)) {
            return GestorCitas.ResultadoOperacion.error("El telefono no tiene un formato valido.");
        }
        if (!Validador.esFechaNacimientoValida(fechaNacimiento)) {
            return GestorCitas.ResultadoOperacion.error("La fecha de nacimiento no es valida.");
        }

        String id = "PAC-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        Paciente paciente = new Paciente(id, nombre, apellido, telefono, email, fechaNacimiento, tipoSangre, direccion);

        boolean guardado = repositorioPaciente.guardar(paciente);
        if (!guardado) {
            return GestorCitas.ResultadoOperacion.error("No se pudo registrar el paciente.");
        }
        return GestorCitas.ResultadoOperacion.exito("Paciente registrado con ID " + id, null);
    }

    public List<Paciente> listarPacientes() {
        return repositorioPaciente.listarTodos();
    }
}
