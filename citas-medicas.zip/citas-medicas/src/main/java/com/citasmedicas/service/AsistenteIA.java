package com.citasmedicas.service;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/**
 * AI assistant scoped exclusively to the medical-appointments domain.
 *
 * Domain restriction strategy (required by the project rubric):
 * 1. A strict system prompt instructs the model to only discuss topics
 *    related to scheduling appointments, specialties, and general guidance
 *    on which specialty to consult for a symptom — never diagnosis,
 *    medication dosages, or anything outside this system's purpose.
 * 2. A lightweight local pre-filter ("guardrail") looks for obvious
 *    off-topic requests before the API is even called, saving cost and
 *    guaranteeing the refusal even if the model misbehaves.
 *
 * Demonstrates ENCAPSULATION: callers only see askQuestion(); the HTTP
 * plumbing and prompt engineering are hidden implementation details.
 */
public class AsistenteIA {

    private static final String API_URL = "https://api.openai.com/v1/chat/completions";
    private static final String MODEL = "gpt-4o-mini";

    private static final String SYSTEM_PROMPT = """
            You are MediBot, a virtual assistant embedded in a medical appointment
            scheduling system. Your ONLY purpose is to help patients with:
            - Understanding which medical specialty might be appropriate for a
              general symptom description (you NEVER diagnose).
            - Explaining how the appointment system works (scheduling, canceling,
              specialties available, what to expect from a visit).
            - General, non-prescriptive health orientation (e.g., "you should see
              a doctor about that") without giving medical treatment advice,
              dosages, or diagnoses.

            STRICT RULES:
            - If the user asks about anything unrelated to medical appointments or
              general health orientation (e.g., entertainment, coding, politics,
              homework, general trivia), politely refuse and redirect them to the
              system's purpose. Do not answer the off-topic question in any way.
            - Never provide a diagnosis, prescribe medication, or give specific
              dosages. Always recommend consulting the assigned doctor in person.
            - Keep responses concise and professional, suitable for a console app.
            """;

    private final String apiKey;
    private final HttpClient httpClient;
    private final List<String[]> historial; // simple (role, content) pairs for short context

    public AsistenteIA(String apiKey) {
        this.apiKey = apiKey;
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(15))
                .build();
        this.historial = new ArrayList<>();
    }

    /**
     * Sends the user's question to the LLM, constrained to the medical domain.
     * Returns a friendly message if the API key is missing or the call fails,
     * so the rest of the app keeps working even without AI configured.
     */
    public String preguntar(String preguntaUsuario) {
        if (apiKey == null || apiKey.isBlank()) {
            return "AI assistant is not configured. Set the OPENAI_API_KEY environment variable to enable it.";
        }

        if (esClaramenteFueraDeDominio(preguntaUsuario)) {
            return "I can only help with topics related to medical appointments and general health "
                    + "orientation within this system. Could you rephrase your question around that?";
        }

        try {
            String jsonBody = construirCuerpoSolicitud(preguntaUsuario);

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(API_URL))
                    .header("Content-Type", "application/json")
                    .header("Authorization", "Bearer " + apiKey)
                    .timeout(Duration.ofSeconds(30))
                    .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                return "AI service returned an error (status " + response.statusCode() + "). "
                        + "Please try again later.";
            }

            String respuesta = extraerRespuesta(response.body());
            historial.add(new String[]{"user", preguntaUsuario});
            historial.add(new String[]{"assistant", respuesta});
            return respuesta;

        } catch (Exception e) {
            return "Could not reach the AI service: " + e.getMessage();
        }
    }

    /**
     * Local guardrail: catches blatantly off-topic requests without spending
     * an API call. This is a defense-in-depth measure, not the only safeguard
     * (the system prompt is the primary one).
     */
    private boolean esClaramenteFueraDeDominio(String pregunta) {
        String p = pregunta.toLowerCase();
        String[] palabrasClaveProhibidas = {
                "codigo", "code", "pelicula", "movie", "chiste", "joke",
                "futbol", "soccer", "receta de cocina", "recipe", "politica", "politics"
        };
        for (String palabra : palabrasClaveProhibidas) {
            if (p.contains(palabra)) {
                return true;
            }
        }
        return false;
    }

    private String construirCuerpoSolicitud(String preguntaUsuario) {
        JSONObject body = new JSONObject();
        body.put("model", MODEL);
        body.put("temperature", 0.3);

        JSONArray messages = new JSONArray();

        JSONObject systemMsg = new JSONObject();
        systemMsg.put("role", "system");
        systemMsg.put("content", SYSTEM_PROMPT);
        messages.put(systemMsg);

        // include brief recent history for context continuity (last 3 exchanges max)
        int inicio = Math.max(0, historial.size() - 6);
        for (int i = inicio; i < historial.size(); i++) {
            JSONObject msg = new JSONObject();
            msg.put("role", historial.get(i)[0]);
            msg.put("content", historial.get(i)[1]);
            messages.put(msg);
        }

        JSONObject userMsg = new JSONObject();
        userMsg.put("role", "user");
        userMsg.put("content", preguntaUsuario);
        messages.put(userMsg);

        body.put("messages", messages);
        return body.toString();
    }

    private String extraerRespuesta(String responseBody) {
        JSONObject json = new JSONObject(responseBody);
        JSONArray choices = json.getJSONArray("choices");
        JSONObject primeraOpcion = choices.getJSONObject(0);
        JSONObject mensaje = primeraOpcion.getJSONObject("message");
        return mensaje.getString("content").trim();
    }
}
