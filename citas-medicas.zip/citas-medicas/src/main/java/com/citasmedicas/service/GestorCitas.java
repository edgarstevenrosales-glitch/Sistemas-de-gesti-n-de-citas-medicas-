package com.citasmedicas.service;

import com.citasmedicas.interfaces.Notificable;
import com.citasmedicas.model.*;
import com.citasmedicas.repository.RepositorioCitas;
import com.citasmedicas.repository.RepositorioMedico;
import com.citasmedicas.repository.RepositorioPaciente;
import com.citasmedicas.util.Validador;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Business logic layer for managing appointments.
 * Demonstrates separation of concerns: this class never talks to JDBC directly,
 * it delegates persistence to the repository classes, and notification to any
 * Notificable implementation (POLYMORPHISM via dependency on the interface).
 */
public class GestorCitas {

    private final RepositorioCitas repositorioCitas;
    private final RepositorioPaciente repositorioPaciente;
    private final RepositorioMedico repositorioMedico;
    private Notificable canalNotificacion;

    public GestorCitas(RepositorioCitas repositorioCitas, RepositorioPaciente repositorioPaciente,
                        RepositorioMedico repositorioMedico, Notificable canalNotificacion) {
        this.repositorioCitas = repositorioCitas;
        this.repositorioPaciente = repositorioPaciente;
        this.repositorioMedico = repositorioMedico;
        this.canalNotificacion = canalNotificacion;
    }

    public void setCanalNotificacion(Notificable canalNotificacion) {
        this.canalNotificacion = canalNotificacion;
    }

    /**
     * Schedules a new appointment after validating business rules:
     * - the date must be in the future
     * - the doctor must not have a conflicting appointment at the same time
     */
    public ResultadoOperacion agendarCita(String pacienteId, String medicoId, Consultorio consultorio,
                                            LocalDateTime fechaHora, String motivo) {
        if (!Validador.esFechaFutura(fechaHora)) {
            return ResultadoOperacion.error("La fecha de la cita debe ser en el futuro.");
        }
        if (!Validador.esTextoNoVacio(motivo)) {
            return ResultadoOperacion.error("Debe especificar un motivo para la cita.");
        }

        Optional<Paciente> paciente = repositorioPaciente.buscarPorId(pacienteId);
        if (paciente.isEmpty()) {
            return ResultadoOperacion.error("Paciente no encontrado.");
        }

        Optional<Medico> medico = repositorioMedico.buscarPorId(medicoId);
        if (medico.isEmpty()) {
            return ResultadoOperacion.error("Medico no encontrado.");
        }
        if (!medico.get().isDisponible()) {
            return ResultadoOperacion.error("El medico seleccionado no esta disponible actualmente.");
        }

        if (repositorioCitas.existeConflictoHorario(medicoId, fechaHora)) {
            return ResultadoOperacion.error("El medico ya tiene una cita agendada en ese horario.");
        }

        String id = "CITA-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        Cita cita = new Cita(id, paciente.get(), medico.get(), consultorio, fechaHora, motivo);

        boolean guardado = repositorioCitas.guardar(cita);
        if (!guardado) {
            return ResultadoOperacion.error("No se pudo guardar la cita en la base de datos.");
        }

        if (canalNotificacion != null) {
            String mensaje = String.format("Su cita con Dr(a). %s ha sido agendada para el %s.",
                    medico.get().getNombreCompleto(), fechaHora);
            canalNotificacion.enviarNotificacion(cita, mensaje);
        }

        return ResultadoOperacion.exito("Cita agendada correctamente con ID " + id, cita);
    }

    public ResultadoOperacion cancelarCita(String citaId) {
        Optional<Cita> citaOpt = repositorioCitas.buscarPorId(citaId);
        if (citaOpt.isEmpty()) {
            return ResultadoOperacion.error("Cita no encontrada.");
        }
        Cita cita = citaOpt.get();
        cita.cancelar();
        repositorioCitas.actualizarEstado(citaId, EstadoCita.CANCELADA);

        if (canalNotificacion != null) {
            canalNotificacion.enviarNotificacion(cita, "Su cita ha sido cancelada.");
        }
        return ResultadoOperacion.exito("Cita cancelada.", cita);
    }

    public ResultadoOperacion confirmarCita(String citaId) {
        Optional<Cita> citaOpt = repositorioCitas.buscarPorId(citaId);
        if (citaOpt.isEmpty()) {
            return ResultadoOperacion.error("Cita no encontrada.");
        }
        Cita cita = citaOpt.get();
        cita.confirmar();
        repositorioCitas.actualizarEstado(citaId, EstadoCita.CONFIRMADA);
        return ResultadoOperacion.exito("Cita confirmada.", cita);
    }

    public List<Cita> listarCitasPorPaciente(String pacienteId) {
        return repositorioCitas.listarPorPaciente(pacienteId);
    }

    public List<Cita> listarCitasPorMedico(String medicoId) {
        return repositorioCitas.listarPorMedico(medicoId);
    }

    public List<Cita> listarTodasLasCitas() {
        return repositorioCitas.listarTodas();
    }

    /**
     * Simple, self-contained result type for service operations,
     * avoiding the need to throw exceptions for expected business-rule failures.
     */
    public static class ResultadoOperacion {
        private final boolean exitoso;
        private final String mensaje;
        private final Cita cita;

        private ResultadoOperacion(boolean exitoso, String mensaje, Cita cita) {
            this.exitoso = exitoso;
            this.mensaje = mensaje;
            this.cita = cita;
        }

        public static ResultadoOperacion exito(String mensaje, Cita cita) {
            return new ResultadoOperacion(true, mensaje, cita);
        }

        public static ResultadoOperacion error(String mensaje) {
            return new ResultadoOperacion(false, mensaje, null);
        }

        public boolean isExitoso() {
            return exitoso;
        }

        public String getMensaje() {
            return mensaje;
        }

        public Optional<Cita> getCita() {
            return Optional.ofNullable(cita);
        }
    }
}
