package com.citasmedicas.notification;

import com.citasmedicas.interfaces.Notificable;
import com.citasmedicas.model.Cita;

/**
 * SMS-based notification channel.
 * Simulated locally; structure is ready to be swapped for a real SMS gateway (e.g., Twilio).
 */
public class NotificacionSMS implements Notificable {

    @Override
    public boolean enviarNotificacion(Cita cita, String mensaje) {
        String telefono = cita.getPaciente().getTelefono();
        System.out.println("[SMS] Para: " + telefono);
        System.out.println("[SMS] Mensaje: " + mensaje);
        return true;
    }

    @Override
    public String getCanal() {
        return "SMS";
    }
}
