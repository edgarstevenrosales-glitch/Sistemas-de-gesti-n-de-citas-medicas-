package com.citasmedicas.notification;

import com.citasmedicas.interfaces.Notificable;
import com.citasmedicas.model.Cita;

/**
 * Email-based notification channel.
 * In this local/console version, "sending" is simulated by printing to the console,
 * but the structure is ready to be swapped for a real SMTP integration (e.g., JavaMail).
 */
public class NotificacionEmail implements Notificable {

    @Override
    public boolean enviarNotificacion(Cita cita, String mensaje) {
        String destinatario = cita.getPaciente().getEmail();
        System.out.println("[EMAIL] Para: " + destinatario);
        System.out.println("[EMAIL] Asunto: Recordatorio de cita medica");
        System.out.println("[EMAIL] Mensaje: " + mensaje);
        return true;
    }

    @Override
    public String getCanal() {
        return "Email";
    }
}
