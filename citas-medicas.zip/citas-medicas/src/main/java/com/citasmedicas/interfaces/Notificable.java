package com.citasmedicas.interfaces;

import com.citasmedicas.model.Cita;

/**
 * Contract for any channel capable of notifying a patient/doctor about an appointment.
 * Demonstrates the use of an INTERFACE and enables POLYMORPHISM: GestorCitas can work
 * with any Notificable implementation without knowing the concrete channel.
 */
public interface Notificable {

    /**
     * Sends a notification related to the given appointment.
     * @return true if the notification was sent successfully.
     */
    boolean enviarNotificacion(Cita cita, String mensaje);

    String getCanal();
}
